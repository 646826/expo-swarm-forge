# Canyon Charms

A complete, original match-3 example for the Swarm browser-game starter. It uses no runtime dependencies, remote fonts, stock art, copied levels, or third-party audio.

## Play locally

From the repository root:

```bash
npm run check -- --project example/canyon-charms
npm run serve -- example/canyon-charms 4173
```

Open `http://127.0.0.1:4173` in a normal local development environment.

## Rules

- Match three or more identical charms on an 8×8 board.
- Four in a horizontal line creates a row beam.
- Four in a vertical line creates a column beam.
- Five in a line or a T/L intersection creates dynamite.
- Reach 5,000 points before 20 accepted moves run out.
- A swap that makes no match is animated back and never spends a move.

The second HUD objective counts created power charms. It teaches the special-tile system and does not secretly change the score-based win rule.

## Controls

- Mouse or touch: tap two neighbors, drag, or swipe.
- Keyboard: arrows move focus; Enter or Space selects; `H` shows a hint; `M` toggles sound; `R` starts a new seeded game; Escape pauses.
- Title and pause surfaces expose sound and reduced-motion preferences.

## Architecture

```text
src/core.js       deterministic rules, PRNG, matches, cascades, scoring
src/platform.js   best-effort settings storage and publisher event port
src/app.js        Canvas presentation, DOM shell, input, animation, Web Audio
```

The renderer consumes serializable state and ordered semantic events. The core never imports browser APIs, wall-clock time, storage, audio, or ambient randomness.

For QA, `window.__CANYON_CHARMS__` exposes stable diagnostics and scripted legal/invalid moves. It is a browser test affordance, not a gameplay dependency.
